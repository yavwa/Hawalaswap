module.exports = {
  norpc: true,
  skipFiles: ["mocks/", "interfaces/", "uniswapv2/"],
}
